﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EncryptionTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"D:\",
                Title = "Browse CSV Files",
                CheckFileExists = true,
                Filter = "CSV files (*.csv)|*.csv",
                CheckPathExists = true,
                RestoreDirectory = true,
                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtInput.Text = openFileDialog1.FileName;
                txtMessage.BackColor = Color.White;
                txtMessage.Text = "";
                txtBatchInput.Text = "";
            }
        }

        private void btnBatchFiles_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            // Show the FolderBrowserDialog.  
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtBatchInput.Text = folderDlg.SelectedPath;
                txtMessage.BackColor = Color.White;
                txtMessage.Text = "";
                txtInput.Text = "";
                Environment.SpecialFolder root = folderDlg.RootFolder;
            }
        }

        private void btnBrowseOutPath_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            // Show the FolderBrowserDialog.  
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtOutputPath.Text = folderDlg.SelectedPath;
                txtMessage.BackColor = Color.White;
                txtMessage.Text = "";
                Environment.SpecialFolder root = folderDlg.RootFolder;
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            if (txtBatchInput.Text != "")
            {
                if (txtOutputPath.Text == "")
                {
                    txtMessage.BackColor = Color.Red;
                    txtMessage.Text = "Please select Output Path";
                    return;
                }
                if (txtPassword.TextLength < 0)
                {
                    txtMessage.BackColor = Color.Red;
                    txtMessage.Text = "Please Input the password for Encryption";
                    return;
                }
                else if (txtPassword.TextLength < 16 || txtPassword.TextLength > 16)
                {
                    txtMessage.BackColor = Color.Red;
                    txtMessage.Text = "Please Input the password having 16 Character length";
                    return;
                }
                var files = Directory.EnumerateFiles(txtBatchInput.Text, "*.csv*");
                foreach (string file in files)
                {
                    string path = file;
                    FileInfo Outputfile = new FileInfo(path);
                    string[] lines = System.IO.File.ReadAllLines(file);
                    var outputPath = txtOutputPath.Text + "\\" + Outputfile.Name.Replace(".csv", "") + ".bin";
                    for (int i = 0; i < lines.Length; i++)
                    {
                        var encry = EncryptStringAES(lines[i], txtPassword.Text);
                        using (StreamWriter w = File.AppendText(outputPath))
                        {
                            w.WriteLine(encry);
                        }
                        Application.DoEvents();
                        txtMessage.BackColor = Color.Yellow;
                        txtMessage.Text = "Processing File: " + Outputfile.Name + ",  Row: " + i + " of  " + lines.Length;
                        Thread.Sleep(10);
                    }
                    txtMessage.BackColor = Color.GreenYellow;
                    txtMessage.Text = "File " + Outputfile.Name + " Saved to Output Path";
                }
                txtMessage.BackColor = Color.GreenYellow;
                txtMessage.Text = "All Files saved to Output Path";
            }
            else if (txtInput.Text != "")
            {
                if (txtOutputPath.Text == "")
                {
                    txtMessage.BackColor = Color.Red;
                    txtMessage.Text = "Please select Output Path";
                    return;
                }
                if (txtPassword.TextLength < 0)
                {
                    txtMessage.BackColor = Color.Red;
                    txtMessage.Text = "Please Input the password for Encryption";
                    return;
                }
                else if (txtPassword.TextLength < 16 || txtPassword.TextLength > 16)
                {
                    txtMessage.BackColor = Color.Red;
                    txtMessage.Text = "Please Input the password having 16 Character length";
                    return;
                }
                string path = txtInput.Text;
                FileInfo Outputfile = new FileInfo(path);
                string[] lines = System.IO.File.ReadAllLines(txtInput.Text);
                var outputPath = txtOutputPath.Text + "\\" + Outputfile.Name.Replace(".csv", "") + ".bin";
                for (int i = 0; i < lines.Length; i++)
                {
                    var encry = EncryptStringAES(lines[i], txtPassword.Text);
                    using (StreamWriter w = File.AppendText(outputPath))
                    {
                        w.WriteLine(encry);
                    }
                    Application.DoEvents();
                    txtMessage.BackColor = Color.Yellow;
                    txtMessage.Text = "Processing File: " + Outputfile.Name + ",  Row: " + i + "  Of  " + lines.Length;
                    Thread.Sleep(10);
                }
                txtMessage.BackColor = Color.GreenYellow;
                txtMessage.Text = "File saved to Output Path";
            }
            else
            {
                txtMessage.BackColor = Color.Red;
                txtMessage.Text = "Please select Input file";
                return;
            }

            //if (txtInput.Text == "")
            //{
            //    txtMessage.BackColor = Color.Red;
            //    txtMessage.Text = "Please select Input file";
            //    return;
            //}
            //if (txtOutputPath.Text == "")
            //{
            //    txtMessage.BackColor = Color.Red;
            //    txtMessage.Text = "Please select Output Path";
            //    return;
            //}
            //if (txtPassword.TextLength < 0)
            //{
            //    txtMessage.BackColor = Color.Red;
            //    txtMessage.Text = "Please Input the password for Encryption";
            //    return;
            //}
            //else if (txtPassword.TextLength < 16 || txtPassword.TextLength > 16)
            //{
            //    txtMessage.BackColor = Color.Red;
            //    txtMessage.Text = "Please Input the password having 16 Character length";
            //    return;
            //}

            //try
            //{
            //    string path = txtInput.Text;
            //    FileInfo Outputfile = new FileInfo(path);
            //    string[] lines = System.IO.File.ReadAllLines(txtInput.Text);
            //    var outputPath = txtOutputPath.Text + "\\" + Outputfile.Name.Replace(".csv", "") + ".bin";
            //    for (int i = 0; i < lines.Length; i++)
            //    {
            //        var encry = EncryptStringAES(lines[i], txtPassword.Text);
            //        using (StreamWriter w = File.AppendText(outputPath))
            //        {
            //            w.WriteLine(encry);
            //        }
            //        Application.DoEvents();
            //        txtMessage.BackColor = Color.Yellow;
            //        txtMessage.Text = "Processing Rows: " + i;
            //        Thread.Sleep(10);
            //    }
            //    txtMessage.BackColor = Color.GreenYellow;
            //    txtMessage.Text = "File saved to Output Path";
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        public static string EncryptStringAES(string plainText, string pass)
        {
            //var keybytes = Encoding.UTF8.GetBytes("8080808080808080");
            var keybytes = Encoding.UTF8.GetBytes(pass);
            var iv = Encoding.UTF8.GetBytes("8080808080808080");

            var encryoFromJavascript = EncryptStringToBytes(plainText, keybytes, iv);
            return Convert.ToBase64String(encryoFromJavascript);
        }

        private static byte[] EncryptStringToBytes(string plainText, byte[] key, byte[] iv)
        {
            // Check arguments.  
            if (plainText == null || plainText.Length <= 0)
            {
                throw new ArgumentNullException("plainText");
            }
            if (key == null || key.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            if (iv == null || iv.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            byte[] encrypted;
            // Create a RijndaelManaged object  
            // with the specified key and IV.  
            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Mode = CipherMode.CBC;
                rijAlg.Padding = PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = key;
                rijAlg.IV = iv;

                // Create a decrytor to perform the stream transform.  
                var encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.  
                using (var msEncrypt = new MemoryStream())
                {
                    using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (var swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.  
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            // Return the encrypted bytes from the memory stream.  
            return encrypted;
        }
       
    }
}
