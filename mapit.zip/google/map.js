var loopS = false;
var loop3S = false;
$(document).ready(function () {
    $("#btnReset").click(function () {
        location.reload();
    });

    // Create the DIV to hold the control and call the CenterControl()
    // constructor passing in this DIV.
    //var centerControlDiv = document.createElement('div');
    //var centerControl = new CenterControl(centerControlDiv, map);

    //centerControlDiv.index = 1;
    //map.controls[google.maps.ControlPosition.BOTTOM_RIGHT].push(centerControlDiv)

    $("#cityLine").click(function () {
        // choose target dropdown
        var select = $('#cityLine');
        select.html(select.find('option').sort(function (x, y) {
            // to change to descending order switch "<" for ">"
            return $(x).text() > $(y).text() ? 1 : -1;
        }));

        // select default item after sorting (first item)
        // $('select').get(0).selectedIndex = 0;
    });

    $("#btnDatatable").click(function () {
        $('#example').DataTable({
            destroy: true,
            "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 150, "All"]],
            data: BusinessCityArray,
            columns: [
                { title: "Sno" },
                { title: "Lat" },
                { title: "Long" },
                { title: "City." },
                { title: "State" },
                { title: "Country" },
                { title: "Type" },
                { title: "D1" },
                { title: "D2" },
                { title: "D3" },
                { title: "D4" },
                { title: "D5" },
                { title: "Date" },
                { title: "Phone" },
                { title: "Fax" },
                { title: "Email" },
                { title: "Url" },
                { title: "IP" },
                { title: "Subnet" },
                { title: "IPRange" },
                { title: "Target" }
            ],
            // info:false
        });
    });

    $("#btnLinetable").click(function () {
        LineDescArray2 = [];
        for (var i = 0; i < LineDescArray.length; i++) {
            LineDescArray2[i] = [i, LineDescArray[i][1], LineDescArray[i][2], LineDescArray[i][3], LineDescArray[i][4], LineDescArray[i][5], LineDescArray[i][6], LineDescArray[i][7], LineDescArray[i][8], LineDescArray[i][9], LineDescArray[i][10], LineDescArray[i][11], LineDescArray[i][12], LineDescArray[i][13], LineDescArray[i][14], LineDescArray[i][15], LineDescArray[i][16]]
        }
        $('#LineTable').DataTable({
            destroy: true,
            "lengthMenu": [[-1, 2000, 2020], ["All", 2000, 2020]],
            data: LineDescArray2,
            columns: [
                { title: "Sno" },
                { title: "Lat1" },
                { title: "Long1" },
                { title: "City1" },
                { title: "State1" },
                { title: "Country1" },
                { title: "Lat2" },
                { title: "Long2" },
                { title: "City2" },
                { title: "State2" },
                { title: "Country2" },
                { title: "Comment" },
                { title: "Date" },
                { title: "SourceIP" },
                { title: "TargetIP" },
                { title: "SourceOwner" },
                { title: "TargetOwner" }
            ],
            // info:false
        });
    });

    var format = "yy.mm.dd";
    var minDate = "2003.01.01";
    var maxDate = "2020.06.30";

    function formatDate(str) {
        var yy = str.slice(0, 4);
        var mm = str.slice(5, 7);
        var dd = str.slice(8);
        var f = yy + "-" + mm + "-" + dd;
        return f;
    }

    function strToDate(f, str) {
        return $.datepicker.parseDate(f, str);
    }

    function dateToStr(f, dt) {
        return $.datepicker.formatDate(f, dt);
    }

    function calcDayDiff(a, b) {
        var d1 = Date.parse(formatDate(a)),
            d2 = Date.parse(formatDate(b)),
            tdf = Math.abs(d2 - d1),
            ddf = Math.ceil(tdf / (1000 * 3600 * 24));
        return ddf;
    }

    function addDays(dt, d) {
        var nt = d * (1000 * 3600 * 24);
        var ndt = new Date(dt.getTime() + nt);
        return ndt;
    }

    function dateToSeconds(dStr) {
        var dt = new Date(dStr);
        return dt.getTime() / 1000;
    }

    $("#slider-range").slider({
        min: 0,
        max: calcDayDiff(minDate, maxDate),
        step: 1,
        // value: calcDayDiff(minDate, "2003.01.01"),
        values: [calcDayDiff(minDate, "2003.01.01"), calcDayDiff(minDate, maxDate)],
        slide: function (event, ui) {
            var dtv = addDays(strToDate(format, minDate), ui.values[0]);
            var dtv2 = addDays(strToDate(format, minDate), ui.values[1]);
            //$("#date-slider-1").val(dateToStr(format, dtv));
            //$("#date-slider-2").val(dateToStr(format, dtv2));
            //SetPolyLine(dateToStr(format, dtv),file2Arr);

        }
    });

    var sdtv = addDays(strToDate(format, "2003.01.01"), $("#slider-range").slider("values", 0));
    //$("#date-slider-1").val(dateToStr(format, sdtv));
    //$("#BusinessSlider").val(dateToStr(format, sdtv));

    var sdtv2 = addDays(strToDate(format, "2020.06.30"), $("#slider-range").slider("values", 0));
    //$("#date-slider-2").val(dateToStr(format, sdtv2));


    var slider1Autoplay = false;
    var intv;


    $("#slider-1-autoplay").on("click", function () {
        // slider1Autoplay = (slider1Autoplay) ? false : true;
        // if (slider1Autoplay == false) {
        //     clearInterval(intv);
        // }
        // intv = setInterval(function () {
        //     var cv = $("#slider-range").slider("values", 0);
        //     var sdtv = addDays(strToDate(format, minDate), ++cv);
        //     $("#slider-range").slider("values", 0, cv);
        //     if($('#chkDisplayDate').is(":checked")){
        //         $("#date-slider-1").val(dateToStr(format, sdtv));
        //     }
        //     SetPolyLine(dateToStr(format, sdtv), file2Arr);
        // }, $("#txtDelayTime").val());
        setFont();
        for (let i = 1; i < file2Arr.length; i++) {
            task(i);
        }
    });

    var intv1;
    function task(i) {
        intv1 = setTimeout(function () {
            if (i > 1) {
                var country = file2Arr[i - 1].split(",")[4];
            }
            SetPolyLine2(0, file2Arr[i], 1, i, file2Arr.length, country)
        }, $("#txtDelayTime").val() * i);
    }

    $("#AbortAutoPlay1").on("click", function () {
        loopS = true;
        clearTimeout(intv1);
    });


    $("#slider-2-autoplay").on("click", function () {
        // slider1Autoplay = (slider1Autoplay) ? false : true;
        // if (slider1Autoplay == false) {
        //     clearInterval(intv);
        // }
        // intv = setInterval(function () {
        //     var cv = $("#slider-range").slider("values", 1);
        //     var sdtv = addDays(strToDate(format, minDate), --cv);
        //     $("#slider-range").slider("values", 1, cv);
        //     if($('#chkDisplayDate').is(":checked")){
        //     $("#date-slider-2").val(dateToStr(format, sdtv));
        //     }
        //     SetPolyLine(dateToStr(format, sdtv), file2Arr);
        // }, $("#txtDelayTime").val());
        setFont();
        for (var j = 1; j < file2Arr.length; j++) {
            task2(j);
        }
    });

    function task2(j) {
        setTimeout(function () {
            var index = parseInt(file2Arr.length) - j;
            if (index > 1) {
                var country = file2Arr[index + 1].split(",")[4];
            }
            SetPolyLine2(0, file2Arr[index], 2, j, file2Arr.length, country)
        }, $("#txtDelayTime").val() * j);
    }

    $("#business-slider").slider({
        min: 0,
        max: calcDayDiff(minDate, maxDate),
        step: 1,
        value: calcDayDiff(minDate, "2003.01.01"),
        // values: [calcDayDiff(minDate, "2003.01.01"), calcDayDiff(minDate, maxDate)],
        slide: function (event, ui) {
            var dtv = addDays(strToDate(format, minDate), ui.value);
            // var dtv2 = addDays(strToDate(format, minDate), ui.values[1]);
            //$("#BusinessSlider").val(dateToStr(format, dtv));
            //ShowBusinessAddresses(dateToStr(format, dtv));

        }
    });

    $("#BusinessSlider-autoplay").on("click", function () {
        // slider1Autoplay = (slider1Autoplay) ? false : true;
        // if (slider1Autoplay == false) {
        //     clearInterval(intv);
        // }
        // intv = setInterval(function () {
        //     var cv = $("#business-slider").slider("values", 0);
        //     var sdtv = addDays(strToDate(format, minDate), ++cv);
        //     $("#business-slider").slider("value", cv);
        //     if($('#chkDisplayDate').is(":checked")){
        //     $("#BusinessSlider").val(dateToStr(format, sdtv));
        //     }
        //     ShowBusinessAddresses(dateToStr(format, sdtv));
        // }, $("#txtDelayTime").val());
        for (let i = 1; i < file4Arr.length; i++) {
            task3(i);
        }

    });

    var intv3;
    function task3(i) {
        intv3 = setTimeout(function () {
            ShowBusinessAddresses2(0, file4Arr[i], i, file4Arr.length, 1);
        }, $("#txtDelayTime").val() * i);
    }


    $("#BusinessSlider-autoplay-reverse").on("click", function () {
        // slider1Autoplay = (slider1Autoplay) ? false : true;
        // if (slider1Autoplay == false) {
        //     clearInterval(intv);
        // }
        // intv = setInterval(function () {
        //     var cv = $("#business-slider").slider("values", 0);
        //     var sdtv = addDays(strToDate(format, minDate), ++cv);
        //     $("#business-slider").slider("value", cv);
        //     if($('#chkDisplayDate').is(":checked")){
        //     $("#BusinessSlider").val(dateToStr(format, sdtv));
        //     }
        //     ShowBusinessAddresses(dateToStr(format, sdtv));
        // }, $("#txtDelayTime").val());
        for (var j = 1; j < file4Arr.length; j++) {
            task4(j);
        }
    });

    function task4(j) {
        setTimeout(function () {
            var index = parseInt(file4Arr.length) - j;
            ShowBusinessAddresses2(0, file4Arr[index], j, file4Arr.length, 2);
        }, $("#txtDelayTime").val() * j);
    }


    $("#AbortAutoPlay3").on("click", function () {
        loop3S = true;
        clearTimeout(intv3);
    });

    var password = "";
    var file1Arr = [];
    $('#fileUpload').on('change', function (e) {
        debugger
        // var value = $("#chkEncryption").val(); 
        if ($('#chkEncryption').is(":checked")) {
            if (password.length < 16) {
                alert('Please enter password!');
                return;
            }
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (progressEvent) {
                // By lines
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    var key = CryptoJS.enc.Utf8.parse(password);
                    var iv = CryptoJS.enc.Utf8.parse('8080808080808080');

                    var decrypted = CryptoJS.AES.decrypt(lines[line], key,
                        {
                            keySize: 128 / 8,
                            iv: iv,
                            mode: CryptoJS.mode.CBC,
                            padding: CryptoJS.pad.Pkcs7
                        });
                    file1Arr.push(decrypted.toString(CryptoJS.enc.Utf8));
                }
                console.log(file1Arr);
            };
            reader.readAsText(file);
        }
        else {
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (e) {
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    file1Arr.push(lines[line]);
                }
                console.log(file1Arr);
            };
            reader.readAsText(file);
        }



    });

    $('#upload').on('click', function (e) {
        getCsvData(file1Arr);
    });

    var file2Arr = [];
    $('#fileUpload2').on('change', function (e) {
        if ($('#chkEncryption').is(":checked")) {
            if (password.length < 16) {
                alert('Please enter password!');
                return;
            }
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (progressEvent) {
                // By lines
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    var key = CryptoJS.enc.Utf8.parse(password);
                    var iv = CryptoJS.enc.Utf8.parse('8080808080808080');

                    var decrypted = CryptoJS.AES.decrypt(lines[line], key,
                        {
                            keySize: 128 / 8,
                            iv: iv,
                            mode: CryptoJS.mode.CBC,
                            padding: CryptoJS.pad.Pkcs7
                        });
                    file2Arr.push(decrypted.toString(CryptoJS.enc.Utf8));
                }
                OnLineSelect(file2Arr)
            };
            reader.readAsText(file);
        }
        else {
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (e) {
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    file2Arr.push(lines[line]);
                }
                console.log(file2Arr);
                OnLineSelect(file2Arr)
            };
            reader.readAsText(file);
        }
    });

    $('#upload2').on('click', function (e) {
        SetPolyLine(0, file2Arr)
    });


    var file3Arr = [];
    $('#fileUpload3').on('change', function (e) {
        if ($('#chkEncryption').is(":checked")) {
            if (password.length < 16) {
                alert('Please enter password!');
                return;
            }
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (progressEvent) {
                // By lines
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    var key = CryptoJS.enc.Utf8.parse(password);
                    var iv = CryptoJS.enc.Utf8.parse('8080808080808080');
                    var decrypted = CryptoJS.AES.decrypt(lines[line], key,
                        {
                            keySize: 128 / 8,
                            iv: iv,
                            mode: CryptoJS.mode.CBC,
                            padding: CryptoJS.pad.Pkcs7
                        });
                    file3Arr.push(decrypted.toString(CryptoJS.enc.Utf8));
                }
                OnCitySelect(file3Arr)
                console.log(file3Arr);
            };
            reader.readAsText(file);
        }
        else {
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (e) {
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    file3Arr.push(lines[line]);
                }
                OnCitySelect(file3Arr)
            };
            reader.readAsText(file);
        }

    });

    var file4Arr = [];
    $('#fileUpload4').on('change', function (e) {
        if ($('#chkEncryption').is(":checked")) {
            if (password.length < 16) {
                alert('Please enter password!');
                return;
            }
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (progressEvent) {
                // By lines
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    var key = CryptoJS.enc.Utf8.parse(password);
                    var iv = CryptoJS.enc.Utf8.parse('8080808080808080');

                    var decrypted = CryptoJS.AES.decrypt(lines[line], key,
                        {
                            keySize: 128 / 8,
                            iv: iv,
                            mode: CryptoJS.mode.CBC,
                            padding: CryptoJS.pad.Pkcs7
                        });
                    file4Arr.push(decrypted.toString(CryptoJS.enc.Utf8));
                }
                OnBusinessSelect(file4Arr)
                console.log(file4Arr);
            };
            reader.readAsText(file);

        }
        else {
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function (e) {
                var lines = this.result.split('\n');
                for (var line = 0; line < lines.length; line++) {
                    file4Arr.push(lines[line]);
                }
                OnBusinessSelect(file4Arr)
            };
            reader.readAsText(file);
        }

    });

    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the button that opens the modal
    var btn = document.getElementById("btnModal");

    // Get the button that close the modal
    var btnClose = document.getElementById("btnClose");

    // Get the button that save the password
    var SavePwd = document.getElementById("btnSetPwd");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal 
    btn.onclick = function () {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks on Close button, close the modal
    btnClose.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks on Save button, close the modal
    SavePwd.onclick = function () {
        password = $('#txtPwd').val();
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

});
var color;
var circle;
var triangle;
var square;
var cross;
var citiesArray = [];
var BusinessArray = [];
var infoWindows = [];
var BusinessCityArray = [];
var LineDescArray = [];
var LineDescArray2 = [];
var LinePath;
var LinePathArray = [];
var maxV;
var minV;
var LineCityDescarray = [];
var CityArr = [];
var LocArr = [];
var LocSpecialArr = [];

//var ImageMarkerArray = [];

function setFont() {
    var chkFont = $('#chkFont:checked').val();
    if (chkFont) {
        $("#txtDate").css("color", "black");
        $("#txtSourceIP").css("color", "black");
        $("#txtSourceOwner").css("color", "black");
        $("#txtSourceCountry").css("color", "black");
        $("#txtSourceID").css("color", "black");
        $("#txtSourceLat").css("color", "black");
        $("#txtSourceLong").css("color", "black");
        $("#txtTargetIP").css("color", "black");
        $("#txtTargetOwner").css("color", "black");
        $("#txtTargetCountry").css("color", "black");
        $("#txtTargetLat").css("color", "black");
        $("#txtTargetLong").css("color", "black");
        $("#txtSuccess").css("color", "black");
       
        $("#txtType").css("color", "black");
        $("#txtBeforeB").css("color", "black");
        $("#txtAfterB").css("color", "black");
        $("#txtBeforeT").css("color", "black");
        $("#txtAfterT").css("color", "black");

        $("#txtBTotal").css("color", "black");
        $("#txtTTotal").css("color", "black");
        $("#txtYcount").css("color", "black");
        $("#txtCountyTotal").css("color", "black");
    }
    else {
        $("#txtDate").css("color", "#f6931f");
        $("#txtSourceIP").css("color", "#f6931f");
        $("#txtSourceOwner").css("color", "#f6931f");
        $("#txtSourceCountry").css("color", "#f6931f");
        $("#txtSourceID").css("color", "#f6931f");
        $("#txtSourceLat").css("color", "#f6931f");
        $("#txtSourceLong").css("color", "#f6931f");
        $("#txtTargetIP").css("color", "#f6931f");
        $("#txtTargetOwner").css("color", "#f6931f");
        $("#txtTargetCountry").css("color", "#f6931f");
        $("#txtTargetLat").css("color", "#f6931f");
        $("#txtTargetLong").css("color", "#f6931f");
        $("#txtSuccess").css("color", "#f6931f");
        
        $("#txtType").css("color", "#f6931f");
        $("#txtBeforeB").css("color", "#f6931f");
        $("#txtAfterB").css("color", "#f6931f");
        $("#txtBeforeT").css("color", "#f6931f");
        $("#txtAfterT").css("color", "#f6931f");

        $("#txtBTotal").css("color", "#f6931f");
        $("#txtTTotal").css("color", "#f6931f");
        $("#txtYcount").css("color", "black");
        $("#txtCountyTotal").css("color", "#f6931f");
    }

}

function loadFile() {
    alert("hello");
    debugger
    var result = null;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "http://www.vault1.org//htdocs/vault1/test/Russian-journalist.csv", false);
    xmlhttp.send();
    if (xmlhttp.status == 200) {
        debugger
        result = xmlhttp.responseText;
    }
    return result;
}


function getColorCode(color) {
    var colorCode = '';
    switch (color) {
        case 'red':
            colorCode = 'de4747';
            break;
        case 'green':
            colorCode = '31bf31';
            break;
        case 'blue':
            colorCode = '0009fe';
            break;
        case 'brown':
            colorCode = '7b5a3b';
            break;
        case 'yellow':
            colorCode = 'ffcc00';
            break;
        case 'black':
            colorCode = '000000';
            break;
        case 'white':
            colorCode = 'faf8f0';
            break;
        case 'orange':
            colorCode = 'ff9933';
            break;
        case 'violet':
            colorCode = '8F00FF';
            break;
    }
    return colorCode;;
}

function getCircleScale(size) {
    var scale = 0.2;
    switch (size) {
        case 't':
            scale = 0.2;
            break;
        case 's':
            scale = 0.3;
            break;
        case 'm':
            scale = 0.4;
            break;
        case 'l':
            scale = 0.5;
            break;
    }
    return scale;;
}

function getTriangleScale(size) {
    var scale = 0.02;
    switch (size) {
        case 't':
            scale = 0.02;
            break;
        case 's':
            scale = 0.05;
            break;
        case 'm':
            scale = 0.1;
            break;
        case 'l':
            scale = 0.2;
            break;
    }
    return scale;;
}

function getSquareScale(size) {
    var scale = 0.05;
    switch (size) {
        case 't':
            scale = 0.05;
            break;
        case 's':
            scale = 0.1;
            break;
        case 'm':
            scale = 0.2;
            break;
        case 'l':
            scale = 0.3;
            break;
    }
    return scale;;
}

function getCrossScale(size) {
    var scale = 0.2;
    switch (size) {
        case 't':
            scale = 0.2;
            break;
        case 's':
            scale = 6;
            break;
        case 'm':
            scale = 7;
            break;
        case 'l':
            scale = 8;
            break;
        default:
            scale = 0.2;
    }
    return scale;;
}

function setCircle(size, color) {
    var scale = getCircleScale(size);
    circle =
    {
        path: 'M 25, 50 a 25,25 0 1,1 50,0 a 25,25 0 1,1 -50,0',// circle
        fillColor: color,
        fillOpacity: 0.8,
        scale: scale,
        strokeColor: color,
        strokeWeight: 2
    };
    return circle;
}

function setTriangle(size, color) {
    var scale = getTriangleScale(size);
    triangle =
    {
        path: 'M150 0 L75 200 L225 200 Z', // triangle
        fillColor: color,
        fillOpacity: 0.8,
        scale: scale,
        strokeColor: color,
        strokeWeight: 2
    };
    return triangle;
}

function setSquare(size, color) {
    var scale = getSquareScale(size);
    square =
    {
        path: 'M 10 10 H 90 V 90 H 10 L 10 10',  //square
        fillColor: color,
        fillOpacity: 0.8,
        scale: scale,
        strokeColor: color,
        strokeWeight: 2
    };
    return square;
}

function setCross(size, color) {
    var scale = getCrossScale(size);
    cross =
    {
        path: 'M0,-1 V2 M-1,0 H1', // cross sign
        fillColor: color,
        fillOpacity: 0.9,
        scale: scale,
        strokeColor: color,
        strokeWeight: 3
    };
    return cross;
}

function GetIcon(shape, size, color) {
    var icon;
    if (shape.trim() == "circle") {
        icon = setCircle(size, color);
    }
    if (shape.trim() == "triangle") {
        icon = setTriangle(size, color);
    }
    if (shape.trim() == "square") {
        icon = setSquare(size, color);
    }
    if (shape.trim() == "cross") {
        icon = setCross(size, color);
    }
    return icon;;
}

function chunkArray(myArray, chunk_size) {
    var index = 0;
    var arrayLength = myArray.length;
    var tempArray = [];

    for (index = 0; index < arrayLength; index += chunk_size) {
        myChunk = myArray.slice(index, index + chunk_size);
        tempArray.push(myChunk);
    }
    return tempArray;
}

function addInfoWindow(marker, message) {

    var infoWindow = new google.maps.InfoWindow({
        content: message
    });

    google.maps.event.addListener(marker, 'click', function () {
        infoWindow.open(map, marker);
    });

    //Store all marker and infowindow in JSON array...
    var dict_map = {};
    dict_map['infoWinObj'] = infoWindow;
    dict_map['markerObj'] = marker;

    //push JSON dict in array
    infoWindows.push(dict_map);
    //
}

function addLinePath(Linepath, map) {
    debugger
    var line_path = {};
    line_path['path'] = Linepath;
    line_path['map'] = map;
    LinePathArray.push(line_path);
}

function CenterControl(controlDiv, map) {

    // Set CSS for the control border.
    var controlUI = document.createElement('div');
    controlUI.style.backgroundColor = '#000000';
    controlUI.style.border = '2px solid #fff';
    controlUI.style.borderRadius = '3px';
    controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
    controlUI.style.cursor = 'pointer';
    controlUI.style.marginBottom = '22px';
    controlUI.style.textAlign = 'center';
    controlUI.title = 'Lat long of the pointer';
    controlDiv.appendChild(controlUI);

    // Set CSS for the control interior.
    var controlText = document.createElement('div');
    controlText.style.color = '#fff';
    controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
    controlText.style.fontSize = '16px';
    controlText.style.lineHeight = '38px';
    controlText.style.paddingLeft = '5px';
    controlText.style.paddingRight = '5px';
    controlText.id = 'LatLongText';
    controlText.innerHTML = '';
    controlUI.appendChild(controlText);

}

function arrayToTable(tableData) {
    var table = $('<table id="example" DataTable class="table table-bordered table-hover table-striped"></table>');
    $(tableData).each(function (i, rowData) {
        var row = $('<tr></tr>');
        $(rowData).each(function (j, cellData) {
            row.append($('<td>' + cellData + '</td>'));
        });
        table.append(row);
    });
    return table;
}

function animateCircle(LinePath) {
    // LinePathArray.push(Linepath);
    var count = 0;
    window.setInterval(function () {
        count = (count + 1) % 200;

        var icons = LinePath.get('icons');
        icons[0].offset = (count / 2) + '%';
        LinePath.set('icons', icons);
    }, 60);
}

function animateallCircle() {
    debugger
    for (var i = 0; i < LinePathArray.length; i++) {
        var LinePath1 = LinePathArray[i]['path']
        var count = 0;
        window.setInterval(function () {
            count = (count + 1) % 200;
            var icons = LinePath1.get('icons');
            icons[0].offset = (count / 2) + '%';
            LinePath1.set('icons', icons);
        }, 60);
    }
}



function getCsvData(file1Arr) {
    debugger
    var points = [];
    for (var i = 0; i < file1Arr.length; i++) {
        var cells = file1Arr[i].split(",");
        if (cells.length > 1) {
            if (i != 0) {
                var obj = {};
                obj['lat'] = parseFloat(cells[0].replace(/"/g, ''));
                obj['lng'] = parseFloat(cells[1].replace(/"/g, ''));
                obj['color'] = cells[2].replace(/"/g, '');
                obj['size'] = cells[3].replace(/"/g, '');
                obj['shape'] = cells[4].replace(/"/g, '');
                //obj["label"] = cells[0].replace (/"/g,'');
                points.push(obj);
            }
        }
    }
    var icon = [];
    var result = chunkArray(points, 100);
    for (i = 0; i < result.length; i++) {
        var TempArraypoint = result[i];
        //  setInterval(function () { 
        for (j = 0; j < TempArraypoint.length; j++) {
            if (TempArraypoint[j].shape.trim() == "pointer") {
                var colorCode = getColorCode(TempArraypoint[j].color)
                if (TempArraypoint[j].size == 't') {
                    icon[j] =
                    {
                        url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                        scaledSize: new google.maps.Size(10, 10), // scaled size
                        //origin: new google.maps.Point(0,0), // origin
                        // anchor: new google.maps.Point(0, 0) // anchor
                    }
                }
                else if (TempArraypoint[j].size == 's') {
                    icon[j] =
                    {
                        url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                        scaledSize: new google.maps.Size(20, 20), // scaled size
                        //origin: new google.maps.Point(0,0), // origin
                        //anchor: new google.maps.Point(0, 0) // anchor
                    }
                }
                else if (TempArraypoint[j].size == 'm') {
                    icon[j] =
                    {
                        url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                        scaledSize: new google.maps.Size(30, 30), // scaled size
                        //origin: new google.maps.Point(0,0), // origin
                        //anchor: new google.maps.Point(0, 0) // anchor
                    }
                }
                else if (TempArraypoint[j].size == 'l') {
                    icon[j] =
                    {
                        url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                        scaledSize: new google.maps.Size(50, 50), // scaled size
                        //origin: new google.maps.Point(0,0), // origin
                        //anchor: new google.maps.Point(0, 0) // anchor
                    }
                }
                // icon[j] = 
                // {
                //     url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                // }
            } else {
                icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
            }
            var marker = new google.maps.Marker({
                position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                map: map,
                icon: icon[j],
                title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
            })
        }
        marker.setMap(map);
        //   }, 4000);
    }
}



function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}

function OnLineSelect(file2Arr) {
    var LineTemparray = [];
    var LineCityarray = [];
    for (var i = 0; i < file2Arr.length; i++) {
        var cells = file2Arr[i].split(",");
        if (cells.length > 1) {
            if (i != 0) {
                var obj = {};
                obj['lat1'] = parseFloat(cells[0].replace(/"/g, ''));
                obj['lng1'] = parseFloat(cells[1].replace(/"/g, ''));
                obj['city1'] = cells[2].replace(/"/g, '');
                obj['state1'] = cells[3].replace(/"/g, '');
                obj['country1'] = cells[4].replace(/"/g, '');
                obj['lat2'] = parseFloat(cells[5].replace(/"/g, ''));
                obj['lng2'] = parseFloat(cells[6].replace(/"/g, ''));
                obj['city2'] = cells[7].replace(/"/g, '');
                obj['state2'] = cells[8].replace(/"/g, '');
                obj['country2'] = cells[9].replace(/"/g, '');
                obj['color'] = cells[10].replace(/"/g, '');
                obj['size'] = cells[11].replace(/"/g, '');
                obj['shape'] = cells[12].replace(/"/g, '');
                obj['lineType'] = cells[13].replace(/"/g, '');
                obj['comment'] = cells[14];
                obj['date'] = cells[15];
                obj['Animation'] = cells[16];
                obj['SourceIP'] = cells[17];
                obj['TargetIP'] = cells[18];
                obj['SourceOwner'] = cells[19];
                obj['TargetOwner'] = cells[20];
                LineTemparray.push(obj);

                if ($.inArray(cells[2].replace(/"/g, ''), LineCityarray) == -1) {
                    LineCityarray.push(cells[2].replace(/"/g, ''));
                    var obj1 = {};
                    obj1['lat1'] = parseFloat(cells[0].replace(/"/g, ''));
                    obj1['lng1'] = parseFloat(cells[1].replace(/"/g, ''));
                    obj1['city1'] = cells[2].replace(/"/g, '');
                    obj1['state1'] = cells[3].replace(/"/g, '');
                    obj1['country1'] = cells[4].replace(/"/g, '');
                    LineCityDescarray.push(obj1);
                }
                if ($.inArray(cells[7].replace(/"/g, ''), LineCityarray) == -1) {
                    LineCityarray.push(cells[7].replace(/"/g, ''));
                    var obj1 = {};
                    obj1['lat1'] = parseFloat(cells[5].replace(/"/g, ''));
                    obj1['lng1'] = parseFloat(cells[6].replace(/"/g, ''));
                    obj1['city1'] = cells[7].replace(/"/g, '');
                    obj1['state1'] = cells[8].replace(/"/g, '');
                    obj1['country1'] = cells[9].replace(/"/g, '');
                    LineCityDescarray.push(obj1);
                }
            }
        }
    }
    for (var i = 0; i < LineTemparray.length; i++) {
        LineDescArray[i] = [i, LineTemparray[i].lat1, LineTemparray[i].lng1, LineTemparray[i].city1, LineTemparray[i].state1, LineTemparray[i].country1, LineTemparray[i].lat2, LineTemparray[i].lng2, LineTemparray[i].city2, LineTemparray[i].state2, LineTemparray[i].country2, LineTemparray[i].comment, LineTemparray[i].date, LineTemparray[i].SourceIP, LineTemparray[i].TargetIP, LineTemparray[i].SourceOwner, LineTemparray[i].TargetOwner]
    }

    maxV = largestInColumn(LineDescArray);
    minV = SmallestInColumn(LineDescArray);
    console.log(maxV);
    console.log(minV);
    // code to fill city dropdown 
    var option1;
    for (var i = 0; i < LineCityDescarray.length; i++) {
        option1 += '<option value="' + LineCityDescarray[i].lat1 + "," + LineCityDescarray[i].lng1 + '">' + LineCityDescarray[i].city1 + '</option>';
    }
    $('#cityLine').append(option1);
}

function OnLineCitychange() {
    var value = $("#cityLine").val(); // returns LatLng object
    var coords = value.split(',');
    var latLng = new google.maps.LatLng(parseFloat(coords[0]), parseFloat(coords[1]));
    map.setCenter(latLng);
    map.setZoom(10);
}

//let map;
let markers1 = [];
let markers2 = [];
var line = [];
var GrandBTotal = 0;
var GrandTTotal = 0;
var YCount = 0;
var CountyTotal = 0;

function SetPolyLine2(year, file2Array, slot, counter, Total, country) {
    if (loopS == true) {
        return;
    }
    $("#messageBoxLines").val(counter + " of " + Total)

    var points = [];
    //alert(file2Array);
    // for (var i = 0; i < file2Array.length; i++) {
    var cells = file2Array.split(",");
    if (cells.length == 28) {
        //  if (i != 0) {
        var obj = {};
        obj['lat1'] = parseFloat(cells[0].replace(/"/g, ''));
        obj['lng1'] = parseFloat(cells[1].replace(/"/g, ''));
        obj['lat2'] = parseFloat(cells[5].replace(/"/g, ''));
        obj['lng2'] = parseFloat(cells[6].replace(/"/g, ''));
        obj['color'] = cells[10].replace(/"/g, '');
        obj['size'] = cells[11].replace(/"/g, '');
        obj['shape'] = cells[12].replace(/"/g, '');
        obj['lineType'] = cells[13].replace(/"/g, '');
        obj['comment'] = cells[14];
        obj['year'] = cells[15];
        obj['animation'] = cells[16];
        points.push(obj);
        //  }
   
    // }
    var checkedLineValue = $('#chkResetLine:checked').val();
    if (checkedLineValue) {
        // initMap();
        for (let i = 0; i < markers1.length; i++) {
            markers1[i].setMap(null);
        }
        for (let i = 0; i < markers2.length; i++) {
            markers2[i].setMap(null);
        }
        for (i = 0; i < line.length; i++) {
            line[i].setMap(null); //or line[i].setVisible(false);
        }
    }

    var checkedValue = $('#chkReset:checked').val();
    if (checkedValue) {
        if (cells[4] != country) {
            // initMap();
            for (let i = 0; i < markers1.length; i++) {
                markers1[i].setMap(null);
            }
            for (let i = 0; i < markers2.length; i++) {
                markers2[i].setMap(null);
            }
            for (i = 0; i < line.length; i++) {
                line[i].setMap(null); //or line[i].setVisible(false);
            }
        }
    }

    var checkedDate = $('#chkDate:checked').val();
    var checkedSourceData = $('#chkSourceData:checked').val();
    var checkedTargetData = $('#chkTargetData:checked').val();
    var checkedStatistics = $('#chkStatistics:checked').val();
    if (checkedDate) {
        $("#txtDate").val(cells[15]);
    }
    if (checkedSourceData) {
        if (cells.length > 1) {
            $("#txtSourceIP").val(cells[17]);
            $("#txtSourceOwner").val(cells[19]);
            $("#txtSourceCountry").val(cells[4]);
            // $("#txtSourceID").val(cells[9]);
            $("#txtSourceLat").val(cells[0]);
            $("#txtSourceLong").val(cells[1]);
        }
    }

    if (checkedTargetData) {
        if (cells.length > 1) {
            $("#txtTargetIP").val(cells[18]);
            $("#txtTargetOwner").val(cells[20]);
            $("#txtTargetCountry").val(cells[9]);
            // $("#txtTargetId").val(cells[10]);
            $("#txtTargetLat").val(cells[5]);
            $("#txtTargetLong").val(cells[6]);
        }
    }

    if (cells[22] == "Y") {
        YCount++;
    }

    if (checkedStatistics) {
        if (cells.length > 1) {
            //var checkedBefore = $('#chkBefore:checked').val();
            //var checkedAfter = $('#chkAfter:checked').val();
            var checkedGroup = $('input[name=Group]:checked').val()
            var checkedTotal = $('#chkTotal:checked').val();
            var checkedSOS = $('#chkSOS:checked').val();
            var checkedCounty = $('#chkCounty:checked').val();

            if (checkedGroup == "Before")
            {
                if (checkedTotal)
                {
                    if (checkedSOS)
                    {
                        if (!(isNaN(cells[24])) && !(isNaN(cells[25])) &&  cells[24] != "*" && cells[25] != "*" && cells[24] != "" && cells[25] != "" && cells[24] != null && cells[25] != null)
                        {
                            var result = searchLocation(LocArr, cells[20].toLowerCase(), cells[8].toLowerCase())
                            if (result == 0)
                            {
                                GrandBTotal = parseInt(GrandBTotal) + parseInt(cells[24]);
                                GrandTTotal = parseInt(GrandTTotal) + parseInt(cells[25]);

                                if (cells[8].toLowerCase() == "connecticut" || cells[8].toLowerCase() == "maine" || cells[8].toLowerCase() == "massachusetts" || cells[8].toLowerCase() == "new hampshire" || cells[8].toLowerCase() == "rhode island" || cells[8].toLowerCase() == "vermont ")
                                {
                                    var specialResult = searchSpecialLocation(LocSpecialArr, cells[8].toLowerCase())
                                    if (specialResult == 0) {
                                        var lenS = LocSpecialArr.length;
                                        LocSpecialArr[lenS] = [cells[8].toLowerCase()];
                                        if (cells[8].toLowerCase() == "connecticut")
                                            CountyTotal += 8;
                                        if (cells[8].toLowerCase() == "maine")
                                            CountyTotal += 16;
                                        if (cells[8].toLowerCase() == "massachusetts")
                                            CountyTotal += 14;
                                        if (cells[8].toLowerCase() == "new hampshire")
                                            CountyTotal += 10;
                                        if (cells[8].toLowerCase() == "rhode island")
                                            CountyTotal += 5;
                                        if (cells[8].toLowerCase() == "vermont")
                                            CountyTotal += 14;
                                    }
                                }
                                else
                                {
                                    CountyTotal++;
                                }

                                var len = LocArr.length;
                                LocArr[len] = [cells[20].toLowerCase(), cells[8].toLowerCase()]
                            }
                        }
                        $("#txtBTotal").val(GrandBTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                        $("#txtTTotal").val(GrandTTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                    }
                    else
                    {
                        if (!(isNaN(cells[24])) && !(isNaN(cells[25])) &&  cells[24] != "*" && cells[25] != "*" && cells[24] != "" && cells[25] != "" && cells[24] != null && cells[25] != null && !(cells[20].toLowerCase().includes("state government office")))
                        {
                            var result = searchLocation(LocArr, cells[20].toLowerCase(), cells[8].toLowerCase())
                            if (result == 0)
                            {
                                GrandBTotal = parseInt(GrandBTotal) + parseInt(cells[24]);
                                GrandTTotal = parseInt(GrandTTotal) + parseInt(cells[25]);

                                if (cells[8].toLowerCase() == "connecticut" || cells[8].toLowerCase() == "maine" || cells[8].toLowerCase() == "massachusetts" || cells[8].toLowerCase() == "new hampshire" || cells[8].toLowerCase() == "rhode island" || cells[8].toLowerCase() == "vermont ") {
                                    var specialResult = searchSpecialLocation(LocSpecialArr, cells[8].toLowerCase())
                                    if (specialResult == 0) {
                                        var lenS = LocSpecialArr.length;
                                        LocSpecialArr[lenS] = [cells[8].toLowerCase()];
                                        if (cells[8].toLowerCase() == "connecticut")
                                            CountyTotal += 8;
                                        if (cells[8].toLowerCase() == "maine")
                                            CountyTotal += 16;
                                        if (cells[8].toLowerCase() == "massachusetts")
                                            CountyTotal += 14;
                                        if (cells[8].toLowerCase() == "new hampshire")
                                            CountyTotal += 10;
                                        if (cells[8].toLowerCase() == "rhode island")
                                            CountyTotal += 5;
                                        if (cells[8].toLowerCase() == "vermont")
                                            CountyTotal += 14;
                                    }
                                }
                                else {
                                    CountyTotal++;
                                }

                                var len = LocArr.length;
                                LocArr[len] = [cells[20].toLowerCase(), cells[8].toLowerCase()]
                            }
                        }
                        $("#txtBTotal").val(GrandBTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                        $("#txtTTotal").val(GrandTTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                    }
                }
                $("#txtSuccess").val(cells[22]);
                $("#txtType").val(cells[23]);
                $("#txtBeforeB").val(cells[24].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                $("#txtAfterB").val(cells[25].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                // $("#txtBeforeT").val(cells[26].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                // $("#txtAfterT").val(cells[27].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                $("#txtYcount").val(YCount);
                if (checkedCounty) {
                    var tempCounty = CountyTotal;
                    if (parseInt(tempCounty) > 3143) {
                        tempCounty = 3143;
                    }
                    $("#txtCountyTotal").val(tempCounty);
                }
            }
            else if (checkedGroup == "After")
            {
                if (checkedTotal)
                {
                    if (checkedSOS)
                    {
                        if (!(isNaN(cells[26])) && !(isNaN(cells[27])) &&  cells[26] != "*" && cells[27] != "*" && cells[26] != "" && cells[27] != "" && cells[26] != null && cells[27] != null)
                        {
                            var result = searchLocation(LocArr, cells[20].toLowerCase(), cells[8].toLowerCase())
                            if (result == 0)
                            {
                                GrandBTotal = parseInt(GrandBTotal) + parseInt(cells[26]);
                                GrandTTotal = parseInt(GrandTTotal) + parseInt(cells[27]);

                                if (cells[8].toLowerCase() == "connecticut" || cells[8].toLowerCase() == "maine" || cells[8].toLowerCase() == "massachusetts" || cells[8].toLowerCase() == "new hampshire" || cells[8].toLowerCase() == "rhode island" || cells[8].toLowerCase() == "vermont ") {
                                    var specialResult = searchSpecialLocation(LocSpecialArr, cells[8].toLowerCase())
                                    if (specialResult == 0) {
                                        var lenS = LocSpecialArr.length;
                                        LocSpecialArr[lenS] = [cells[8].toLowerCase()];
                                        if (cells[8].toLowerCase() == "connecticut")
                                            CountyTotal += 8;
                                        if (cells[8].toLowerCase() == "maine")
                                            CountyTotal += 16;
                                        if (cells[8].toLowerCase() == "massachusetts")
                                            CountyTotal += 14;
                                        if (cells[8].toLowerCase() == "new hampshire")
                                            CountyTotal += 10;
                                        if (cells[8].toLowerCase() == "rhode island")
                                            CountyTotal += 5;
                                        if (cells[8].toLowerCase() == "vermont")
                                            CountyTotal += 14;
                                    }
                                }
                                else {
                                    CountyTotal++;
                                }

                                var len = LocArr.length;
                                LocArr[len] = [cells[20].toLowerCase(), cells[8].toLowerCase()]
                            }
                        }
                        $("#txtBTotal").val(GrandBTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                        $("#txtTTotal").val(GrandTTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                    }
                    else
                    {
                        if (!(isNaN(cells[26])) && !(isNaN(cells[27])) &&  cells[26] != "*" && cells[27] != "*" && cells[26] != "" && cells[27] != "" && cells[26] != null && cells[27] != null && !(cells[20].toLowerCase().includes("state government office")))
                        {
                            var result = searchLocation(LocArr, cells[20].toLowerCase(), cells[8].toLowerCase())
                            if (result == 0)
                            {
                                GrandBTotal = parseInt(GrandBTotal) + parseInt(cells[26]);
                                GrandTTotal = parseInt(GrandTTotal) + parseInt(cells[27]);

                                if (cells[8].toLowerCase() == "connecticut" || cells[8].toLowerCase() == "maine" || cells[8].toLowerCase() == "massachusetts" || cells[8].toLowerCase() == "new hampshire" || cells[8].toLowerCase() == "rhode island" || cells[8].toLowerCase() == "vermont ") {
                                    var specialResult = searchSpecialLocation(LocSpecialArr, cells[8].toLowerCase())
                                    if (specialResult == 0) {
                                        var lenS = LocSpecialArr.length;
                                        LocSpecialArr[lenS] = [cells[8].toLowerCase()];
                                        if (cells[8].toLowerCase() == "connecticut")
                                            CountyTotal += 8;
                                        if (cells[8].toLowerCase() == "maine")
                                            CountyTotal += 16;
                                        if (cells[8].toLowerCase() == "massachusetts")
                                            CountyTotal += 14;
                                        if (cells[8].toLowerCase() == "new hampshire")
                                            CountyTotal += 10;
                                        if (cells[8].toLowerCase() == "rhode island")
                                            CountyTotal += 5;
                                        if (cells[8].toLowerCase() == "vermont")
                                            CountyTotal += 14;
                                    }
                                }
                                else {
                                    CountyTotal++;
                                }

                                var len = LocArr.length;
                                LocArr[len] = [cells[20].toLowerCase(), cells[8].toLowerCase()]
                                debugger
                            }
                            
                        }
                        $("#txtBTotal").val(GrandBTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                        $("#txtTTotal").val(GrandTTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                    }
                }
                $("#txtSuccess").val(cells[22]);
                $("#txtType").val(cells[23]);
                $("#txtBeforeB").val(cells[26].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                $("#txtAfterB").val(cells[27].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                // $("#txtBeforeT").val(cells[26].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                // $("#txtAfterT").val(cells[27].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                $("#txtYcount").val(YCount);
                if (checkedCounty) {
                    var tempCounty = CountyTotal;
                    if (parseInt(tempCounty) > 3143) {
                        tempCounty = 3143;
                    }
                    $("#txtCountyTotal").val(tempCounty);
                }
            }
        }
    }

    var icon = [];
    var result = chunkArray(points, 100);
    var selectedyear = year;
    var MOD = $("#txtMOD").val();

    for (i = 0; i < result.length; i++) {
        var TempArraypoint = result[i];
        for (j = 0; j < TempArraypoint.length; j++) {
            var showGreenLines = $('#chkshowGreenLines:checked').val();
            if (!showGreenLines) {
                if (counter % MOD == 0) {
                    if (selectedyear == 0) {

                        var colorCode = getColorCode(TempArraypoint[j].color)
                        if (TempArraypoint[j].shape.trim() == "pointer") {
                            if (TempArraypoint[j].size == 't') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(10, 10), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 's') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(20, 20), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'm') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(30, 30), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'l') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(50, 50), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            // icon[j] =
                            //     {
                            //        url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                            //     }
                        }
                        else {
                            icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                        }
                        var marker = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat1, TempArraypoint[j].lng1),
                            map: map,
                            icon: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|800080",
                            // icon: icon[j],
                            title: TempArraypoint[j].lat1 + "," + TempArraypoint[j].lng1,
                            //label: TempArraypoint[j].comment
                        })
                        var marker2 = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat2, TempArraypoint[j].lng2),
                            map: map,
                            icon: icon[j],
                            title: TempArraypoint[j].lat2 + "," + TempArraypoint[j].lng2,
                            //label:TempArraypoint[j].comment
                        })
                        markers1.push(marker);
                        markers2.push(marker2);

                        marker.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        marker2.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        if (TempArraypoint[j].comment.trim() != "") {
                            addInfoWindow(marker, TempArraypoint[j].comment.trim());
                            addInfoWindow(marker2, TempArraypoint[j].comment.trim());
                        }
                        var LineCoordinates = [
                            { lat: TempArraypoint[j].lat1, lng: TempArraypoint[j].lng1 },
                            { lat: TempArraypoint[j].lat2, lng: TempArraypoint[j].lng2 }
                        ];
                        var lineSymbol;

                        if (TempArraypoint[j].lineType.trim() == "arrow") {
                            lineSymbol = {
                                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "dash") {
                            lineSymbol = {
                                path: 'M 0,-1 0,1',
                                strokeOpacity: 1,
                                scale: 4
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "straight") {
                            var lineSymbol1 = {
                                path: google.maps.SymbolPath.CIRCLE,
                                scale: 4,
                                strokeColor: colorCode
                            };
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                icons: [{
                                    icon: lineSymbol1,
                                    offset: '100%'
                                }],
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                            });
                            line.push(LinePath);
                            //animateCircle(LinePath);
                        }
                        else if (TempArraypoint[j].lineType.trim() == "arrow") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '100%'
                                }]
                            });
                            line.push(LinePath);
                        }
                        else if (TempArraypoint[j].lineType.trim() == "dash") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '0',
                                    repeat: '20px'
                                }],
                            });
                            line.push(LinePath);
                        }
                        LinePath.setMap(map);
                        // addLinePath(Linepath,map)
                        if (TempArraypoint[j].animation.trim() == "on") {
                            animateCircle(LinePath);
                        }
                        marker.setMap(map);
                        marker2.setMap(map);
                        if (slot == 1) {
                            $("#date-slider-1").val(TempArraypoint[j].year.trim());
                        } else if (slot == 2) {
                            $("#date-slider-2").val(TempArraypoint[j].year.trim());
                        }

                    }
                    else if (TempArraypoint[j].year.trim() == selectedyear) {

                        var colorCode = getColorCode(TempArraypoint[j].color)
                        if (TempArraypoint[j].shape.trim() == "pointer") {
                            if (TempArraypoint[j].size == 't') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(10, 10), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 's') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(20, 20), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'm') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(30, 30), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'l') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(50, 50), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            // icon[j] =
                            //     {
                            //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                            //     }
                        }
                        else {
                            icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                        }
                        var marker = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat1, TempArraypoint[j].lng1),
                            map: map,
                            icon: icon[j],
                            title: TempArraypoint[j].lat1 + "," + TempArraypoint[j].lng1,
                            //label: TempArraypoint[j].comment
                        })
                        var marker2 = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat2, TempArraypoint[j].lng2),
                            map: map,
                            icon: icon[j],
                            title: TempArraypoint[j].lat2 + "," + TempArraypoint[j].lng2,
                            //label:TempArraypoint[j].comment
                        })
                        marker.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        marker2.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        if (TempArraypoint[j].comment.trim() != "") {
                            addInfoWindow(marker, TempArraypoint[j].comment.trim());
                            addInfoWindow(marker2, TempArraypoint[j].comment.trim());
                        }
                        var LineCoordinates = [
                            { lat: TempArraypoint[j].lat1, lng: TempArraypoint[j].lng1 },
                            { lat: TempArraypoint[j].lat2, lng: TempArraypoint[j].lng2 }
                        ];
                        var lineSymbol;

                        if (TempArraypoint[j].lineType.trim() == "arrow") {
                            lineSymbol = {
                                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "dash") {
                            lineSymbol = {
                                path: 'M 0,-1 0,1',
                                strokeOpacity: 1,
                                scale: 4
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "straight") {
                            var lineSymbol1 = {
                                path: google.maps.SymbolPath.CIRCLE,
                                scale: 4,
                                strokeColor: colorCode
                            };
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                icons: [{
                                    icon: lineSymbol1,
                                    offset: '100%'
                                }],
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                            });
                            if (TempArraypoint[j].animation.trim() == "on") {
                                animateCircle(LinePath);
                            }
                        }
                        else if (TempArraypoint[j].lineType.trim() == "arrow") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '100%'
                                }]
                            });
                        }
                        else if (TempArraypoint[j].lineType.trim() == "dash") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '0',
                                    repeat: '20px'
                                }],
                            });
                        }

                        LinePath.setMap(map);
                        //animateCircle(LinePath);
                        marker.setMap(map);
                        marker2.setMap(map);
                    }
                }
            }
            else {
                if (TempArraypoint[j].color == "green") {
                    if (selectedyear == 0) {

                        var colorCode = getColorCode(TempArraypoint[j].color)
                        if (TempArraypoint[j].shape.trim() == "pointer") {
                            if (TempArraypoint[j].size == 't') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(10, 10), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 's') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(20, 20), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'm') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(30, 30), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'l') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(50, 50), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            // icon[j] =
                            //     {
                            //        url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                            //     }
                        }
                        else {
                            icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                        }
                        var marker = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat1, TempArraypoint[j].lng1),
                            map: map,
                            icon: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|800080",
                            // icon: icon[j],
                            title: TempArraypoint[j].lat1 + "," + TempArraypoint[j].lng1,
                            //label: TempArraypoint[j].comment
                        })
                        var marker2 = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat2, TempArraypoint[j].lng2),
                            map: map,
                            icon: icon[j],
                            title: TempArraypoint[j].lat2 + "," + TempArraypoint[j].lng2,
                            //label:TempArraypoint[j].comment
                        })
                        markers1.push(marker);
                        markers2.push(marker2);

                        marker.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        marker2.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        if (TempArraypoint[j].comment.trim() != "") {
                            addInfoWindow(marker, TempArraypoint[j].comment.trim());
                            addInfoWindow(marker2, TempArraypoint[j].comment.trim());
                        }
                        var LineCoordinates = [
                            { lat: TempArraypoint[j].lat1, lng: TempArraypoint[j].lng1 },
                            { lat: TempArraypoint[j].lat2, lng: TempArraypoint[j].lng2 }
                        ];
                        var lineSymbol;

                        if (TempArraypoint[j].lineType.trim() == "arrow") {
                            lineSymbol = {
                                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "dash") {
                            lineSymbol = {
                                path: 'M 0,-1 0,1',
                                strokeOpacity: 1,
                                scale: 4
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "straight") {
                            var lineSymbol1 = {
                                path: google.maps.SymbolPath.CIRCLE,
                                scale: 4,
                                strokeColor: colorCode
                            };
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                icons: [{
                                    icon: lineSymbol1,
                                    offset: '100%'
                                }],
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                            });
                            line.push(LinePath);
                            //animateCircle(LinePath);
                        }
                        else if (TempArraypoint[j].lineType.trim() == "arrow") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '100%'
                                }]
                            });
                            line.push(LinePath);
                        }
                        else if (TempArraypoint[j].lineType.trim() == "dash") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '0',
                                    repeat: '20px'
                                }],
                            });
                            line.push(LinePath);
                        }
                        LinePath.setMap(map);
                        // addLinePath(Linepath,map)
                        if (TempArraypoint[j].animation.trim() == "on") {
                            animateCircle(LinePath);
                        }
                        marker.setMap(map);
                        marker2.setMap(map);
                        if (slot == 1) {
                            $("#date-slider-1").val(TempArraypoint[j].year.trim());
                        } else if (slot == 2) {
                            $("#date-slider-2").val(TempArraypoint[j].year.trim());
                        }

                    }
                    else if (TempArraypoint[j].year.trim() == selectedyear) {

                        var colorCode = getColorCode(TempArraypoint[j].color)
                        if (TempArraypoint[j].shape.trim() == "pointer") {
                            if (TempArraypoint[j].size == 't') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(10, 10), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 's') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(20, 20), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'm') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(30, 30), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            else if (TempArraypoint[j].size == 'l') {
                                icon[j] =
                                {
                                    url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                                    scaledSize: new google.maps.Size(50, 50), // scaled size
                                    //origin: new google.maps.Point(0,0), // origin
                                    //anchor: new google.maps.Point(0, 0) // anchor
                                }
                            }
                            // icon[j] =
                            //     {
                            //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                            //     }
                        }
                        else {
                            icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                        }
                        var marker = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat1, TempArraypoint[j].lng1),
                            map: map,
                            icon: icon[j],
                            title: TempArraypoint[j].lat1 + "," + TempArraypoint[j].lng1,
                            //label: TempArraypoint[j].comment
                        })
                        var marker2 = new google.maps.Marker({
                            position: new google.maps.LatLng(TempArraypoint[j].lat2, TempArraypoint[j].lng2),
                            map: map,
                            icon: icon[j],
                            title: TempArraypoint[j].lat2 + "," + TempArraypoint[j].lng2,
                            //label:TempArraypoint[j].comment
                        })
                        marker.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        marker2.addListener('click', function (e) {
                            document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                        });
                        if (TempArraypoint[j].comment.trim() != "") {
                            addInfoWindow(marker, TempArraypoint[j].comment.trim());
                            addInfoWindow(marker2, TempArraypoint[j].comment.trim());
                        }
                        var LineCoordinates = [
                            { lat: TempArraypoint[j].lat1, lng: TempArraypoint[j].lng1 },
                            { lat: TempArraypoint[j].lat2, lng: TempArraypoint[j].lng2 }
                        ];
                        var lineSymbol;

                        if (TempArraypoint[j].lineType.trim() == "arrow") {
                            lineSymbol = {
                                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "dash") {
                            lineSymbol = {
                                path: 'M 0,-1 0,1',
                                strokeOpacity: 1,
                                scale: 4
                            };
                        }

                        if (TempArraypoint[j].lineType.trim() == "straight") {
                            var lineSymbol1 = {
                                path: google.maps.SymbolPath.CIRCLE,
                                scale: 4,
                                strokeColor: colorCode
                            };
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                icons: [{
                                    icon: lineSymbol1,
                                    offset: '100%'
                                }],
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                            });
                            if (TempArraypoint[j].animation.trim() == "on") {
                                animateCircle(LinePath);
                            }
                        }
                        else if (TempArraypoint[j].lineType.trim() == "arrow") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '100%'
                                }]
                            });
                        }
                        else if (TempArraypoint[j].lineType.trim() == "dash") {
                            LinePath = new google.maps.Polyline({
                                path: LineCoordinates,
                                geodesic: true,
                                strokeColor: "#" + colorCode,
                                strokeOpacity: 0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '0',
                                    repeat: '20px'
                                }],
                            });
                        }

                        LinePath.setMap(map);
                        //animateCircle(LinePath);
                        marker.setMap(map);
                        marker2.setMap(map);
                    }
                }
            }

        }
    }

    }
}

function SetPolyLine(year, file2Arr) {
    var points = [];
    for (var i = 0; i < file2Arr.length; i++) {
        var cells = file2Arr[i].split(",");
        if (cells.length > 1) {
            if (i != 0) {
                var obj = {};
                obj['lat1'] = parseFloat(cells[0].replace(/"/g, ''));
                obj['lng1'] = parseFloat(cells[1].replace(/"/g, ''));
                obj['lat2'] = parseFloat(cells[5].replace(/"/g, ''));
                obj['lng2'] = parseFloat(cells[6].replace(/"/g, ''));
                obj['color'] = cells[10].replace(/"/g, '');
                obj['size'] = cells[11].replace(/"/g, '');
                obj['shape'] = cells[12].replace(/"/g, '');
                obj['lineType'] = cells[13].replace(/"/g, '');
                obj['comment'] = cells[14];
                obj['year'] = cells[15];
                obj['animation'] = cells[16];
                points.push(obj);
            }
        }
    }

    var icon = [];
    var result = chunkArray(points, 100);
    var selectedyear = year;

    for (i = 0; i < result.length; i++) {
        var TempArraypoint = result[i];
        for (j = 0; j < TempArraypoint.length; j++) {
            if (selectedyear == 0) {

                var colorCode = getColorCode(TempArraypoint[j].color)
                if (TempArraypoint[j].shape.trim() == "pointer") {
                    if (TempArraypoint[j].size == 't') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(10, 10), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 's') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(20, 20), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'm') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(30, 30), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'l') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(50, 50), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    // icon[j] =
                    //     {
                    //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                    //     }
                }
                else {
                    icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                }
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(TempArraypoint[j].lat1, TempArraypoint[j].lng1),
                    map: map,
                    icon: icon[j],
                    title: TempArraypoint[j].lat1 + "," + TempArraypoint[j].lng1,
                    //label: TempArraypoint[j].comment
                })
                var marker2 = new google.maps.Marker({
                    position: new google.maps.LatLng(TempArraypoint[j].lat2, TempArraypoint[j].lng2),
                    map: map,
                    icon: icon[j],
                    title: TempArraypoint[j].lat2 + "," + TempArraypoint[j].lng2,
                    //label:TempArraypoint[j].comment
                })
                marker.addListener('click', function (e) {
                    document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                });
                marker2.addListener('click', function (e) {
                    document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                });
                if (TempArraypoint[j].comment.trim() != "") {
                    addInfoWindow(marker, TempArraypoint[j].comment.trim());
                    addInfoWindow(marker2, TempArraypoint[j].comment.trim());
                }
                var LineCoordinates = [
                    { lat: TempArraypoint[j].lat1, lng: TempArraypoint[j].lng1 },
                    { lat: TempArraypoint[j].lat2, lng: TempArraypoint[j].lng2 }
                ];
                var lineSymbol;

                if (TempArraypoint[j].lineType.trim() == "arrow") {
                    lineSymbol = {
                        path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                    };
                }

                if (TempArraypoint[j].lineType.trim() == "dash") {
                    lineSymbol = {
                        path: 'M 0,-1 0,1',
                        strokeOpacity: 1,
                        scale: 4
                    };
                }

                if (TempArraypoint[j].lineType.trim() == "straight") {
                    var lineSymbol1 = {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 4,
                        strokeColor: colorCode
                    };
                    LinePath = new google.maps.Polyline({
                        path: LineCoordinates,
                        icons: [{
                            icon: lineSymbol1,
                            offset: '100%'
                        }],
                        geodesic: true,
                        strokeColor: "#" + colorCode,
                        strokeOpacity: 1.0,
                        strokeWeight: 2,
                    });
                    //animateCircle(LinePath);
                }
                else if (TempArraypoint[j].lineType.trim() == "arrow") {
                    LinePath = new google.maps.Polyline({
                        path: LineCoordinates,
                        geodesic: true,
                        strokeColor: "#" + colorCode,
                        strokeOpacity: 1.0,
                        strokeWeight: 2,
                        icons: [{
                            icon: lineSymbol,
                            offset: '100%'
                        }]
                    });
                }
                else if (TempArraypoint[j].lineType.trim() == "dash") {
                    LinePath = new google.maps.Polyline({
                        path: LineCoordinates,
                        geodesic: true,
                        strokeColor: "#" + colorCode,
                        strokeOpacity: 0,
                        strokeWeight: 2,
                        icons: [{
                            icon: lineSymbol,
                            offset: '0',
                            repeat: '20px'
                        }],
                    });
                }
                LinePath.setMap(map);
                // addLinePath(Linepath,map)
                if (TempArraypoint[j].animation.trim() == "on") {
                    animateCircle(LinePath);
                }
                marker.setMap(map);
                marker2.setMap(map);
            }
            else if (TempArraypoint[j].year.trim() == selectedyear) {

                var colorCode = getColorCode(TempArraypoint[j].color)
                if (TempArraypoint[j].shape.trim() == "pointer") {
                    if (TempArraypoint[j].size == 't') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(10, 10), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 's') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(20, 20), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'm') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(30, 30), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'l') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(50, 50), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    // icon[j] =
                    //     {
                    //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                    //     }
                }
                else {
                    icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                }
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(TempArraypoint[j].lat1, TempArraypoint[j].lng1),
                    map: map,
                    icon: icon[j],
                    title: TempArraypoint[j].lat1 + "," + TempArraypoint[j].lng1,
                    //label: TempArraypoint[j].comment
                })
                var marker2 = new google.maps.Marker({
                    position: new google.maps.LatLng(TempArraypoint[j].lat2, TempArraypoint[j].lng2),
                    map: map,
                    icon: icon[j],
                    title: TempArraypoint[j].lat2 + "," + TempArraypoint[j].lng2,
                    //label:TempArraypoint[j].comment
                })
                marker.addListener('click', function (e) {
                    document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                });
                marker2.addListener('click', function (e) {
                    document.getElementById('LatLongText').innerHTML = '<p>Lat: ' + e.latLng.lat().toFixed(3) + ', Lng: ' + e.latLng.lng().toFixed(3) + '</p>';
                });
                if (TempArraypoint[j].comment.trim() != "") {
                    addInfoWindow(marker, TempArraypoint[j].comment.trim());
                    addInfoWindow(marker2, TempArraypoint[j].comment.trim());
                }
                var LineCoordinates = [
                    { lat: TempArraypoint[j].lat1, lng: TempArraypoint[j].lng1 },
                    { lat: TempArraypoint[j].lat2, lng: TempArraypoint[j].lng2 }
                ];
                var lineSymbol;

                if (TempArraypoint[j].lineType.trim() == "arrow") {
                    lineSymbol = {
                        path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                    };
                }

                if (TempArraypoint[j].lineType.trim() == "dash") {
                    lineSymbol = {
                        path: 'M 0,-1 0,1',
                        strokeOpacity: 1,
                        scale: 4
                    };
                }

                if (TempArraypoint[j].lineType.trim() == "straight") {
                    var lineSymbol1 = {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 4,
                        strokeColor: colorCode
                    };
                    LinePath = new google.maps.Polyline({
                        path: LineCoordinates,
                        icons: [{
                            icon: lineSymbol1,
                            offset: '100%'
                        }],
                        geodesic: true,
                        strokeColor: "#" + colorCode,
                        strokeOpacity: 1.0,
                        strokeWeight: 2,
                    });
                    if (TempArraypoint[j].animation.trim() == "on") {
                        animateCircle(LinePath);
                    }
                }
                else if (TempArraypoint[j].lineType.trim() == "arrow") {
                    LinePath = new google.maps.Polyline({
                        path: LineCoordinates,
                        geodesic: true,
                        strokeColor: "#" + colorCode,
                        strokeOpacity: 1.0,
                        strokeWeight: 2,
                        icons: [{
                            icon: lineSymbol,
                            offset: '100%'
                        }]
                    });
                }
                else if (TempArraypoint[j].lineType.trim() == "dash") {
                    LinePath = new google.maps.Polyline({
                        path: LineCoordinates,
                        geodesic: true,
                        strokeColor: "#" + colorCode,
                        strokeOpacity: 0,
                        strokeWeight: 2,
                        icons: [{
                            icon: lineSymbol,
                            offset: '0',
                            repeat: '20px'
                        }],
                    });
                }

                LinePath.setMap(map);
                //animateCircle(LinePath);
                marker.setMap(map);
                marker2.setMap(map);
            }
        }

    }
}s


var d = 0;
var timerCity;
function CityAutoScan() {
    debugger;
    timerCity = setTimeout(function () {
        var latLng = new google.maps.LatLng(parseFloat(LineCityDescarray[d].lat1), parseFloat(LineCityDescarray[d].lng1));
        map.setCenter(latLng);
        //map.setZoom(10);
        var zoomLevelC = $("#zoomLines").val();
        map.setZoom(parseInt(zoomLevelC));
        document.getElementById('LineCityStateCountry').innerHTML = LineCityDescarray[d].city1 + ",    " + LineCityDescarray[d].state1 + ",    " + LineCityDescarray[d].country1;
        d++;
        if (d < LineCityDescarray.length) {
            CityAutoScan();
        }
    }, 5000)
}

function AbortCityScan() {
    clearTimeout(timerCity);
}

function OnCitySelect(file3Arr) {
    var countryArray = [];
    for (var i = 0; i < file3Arr.length; i++) {
        var cells = file3Arr[i].split(",");
        if (cells.length > 1) {
            if (i != 0) {
                var obj = {};
                obj['lat'] = parseFloat(cells[0].replace(/"/g, ''));
                obj['lng'] = parseFloat(cells[1].replace(/"/g, ''));
                obj['city'] = cells[2].replace(/"/g, '').trim();
                obj['state'] = cells[4].replace(/"/g, '').trim();
                obj['country'] = cells[3].replace(/"/g, '').trim();
                citiesArray.push(obj);
            }
        }
    }
    for (var i = 0; i < file3Arr.length; i++) {
        var cells = file3Arr[i].split(",");
        if (cells.length > 1) {
            if (i != 0) {
                if ($.inArray(cells[3].replace(/"/g, ''), countryArray) == -1) {
                    countryArray.push(cells[3].replace(/"/g, ''));
                }
            }
        }
    }

    // code to fill country dropdown
    var option = '';
    for (var i = 0; i < countryArray.length; i++) {
        option += '<option value="' + (i + 1) + '">' + countryArray[i].trim() + '</option>';
    }
    $('#country').append(option);

    // code to fill city dropdown '<option value="0"> select City </option>'
    var option1;
    for (var i = 0; i < citiesArray.length; i++) {
        option1 += '<option value="' + citiesArray[i].lat + "," + citiesArray[i].lng + '">' + citiesArray[i].city + '</option>';
    }
    $('#city').append(option1);

}

function FillCityOnCountryChange() {
    $("#city").empty();
    // code to fill city dropdown
    var Country = $("#country option:selected").text();
    var option1 = '<option value="0"> select City </option>';
    for (var i = 0; i < citiesArray.length; i++) {
        if (citiesArray[i].country == Country) {
            option1 += '<option value="' + citiesArray[i].lat + "," + citiesArray[i].lng + '">' + citiesArray[i].city + '</option>';
        }
    }
    $('#city').append(option1);
}

function OnCitychange() {
    var value = $("#city").val(); // returns LatLng object
    var coords = value.split(',');
    var latLng = new google.maps.LatLng(parseFloat(coords[0]), parseFloat(coords[1]));
    map.setCenter(latLng);
    map.setZoom(10);
}

function CitySubmit() {
    var result = chunkArray(citiesArray, 100);
    var Country = $("#country option:selected").text();
    for (i = 0; i < result.length; i++) {
        var TempArraypoint = result[i];
        for (j = 0; j < TempArraypoint.length; j++) {
            if (TempArraypoint[j].country == Country) {
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                    map: map,
                    //icon: icon[j],
                    title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                    //label: TempArraypoint[j].city
                })
            }
            else if (Country == "All") {
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                    map: map,
                    //icon: icon[j],
                    title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                    //label: TempArraypoint[j].city
                })
            }
        }
        marker.setMap(map);
    }
}



function OnBusinessSelect(file4Arr) {
    var typeArray = [];
    for (var i = 0; i < file4Arr.length; i++) {
        var cells = file4Arr[i].split(",");
        if (cells.length > 1) {
            if (i != 0) {
                var obj = {};
                obj['lat'] = parseFloat(cells[0].replace(/"/g, ''));
                obj['lng'] = parseFloat(cells[1].replace(/"/g, ''));
                obj['city'] = cells[2].replace(/"/g, '').trim();
                obj['state'] = cells[3].replace(/"/g, '').trim();
                obj['country'] = cells[4].replace(/"/g, '').trim();
                obj['description'] = cells[5].replace(/"/g, '').trim();
                obj['type'] = cells[6].trim();
                obj['color'] = cells[7];
                obj['size'] = cells[8];
                obj['shape'] = cells[9];
                obj['description2'] = cells[10];
                obj['description3'] = cells[11];
                obj['description4'] = cells[12];
                obj['description5'] = cells[13];
                obj['year'] = cells[14];
                obj['phone'] = cells[15];
                obj['fax'] = cells[16];
                obj['email'] = cells[17];
                obj['url'] = cells[18];
                obj['ip'] = cells[19];
                obj['subnet'] = cells[20];
                obj['iprange'] = cells[21];
                obj['target'] = cells[22];
                BusinessArray.push(obj);

                if ($.inArray(cells[6].replace(/"/g, ''), typeArray) == -1) {
                    typeArray.push(cells[6].replace(/"/g, ''));
                }
            }
        }
    }

    for (var i = 0; i < BusinessArray.length; i++) {
        BusinessCityArray[i] = [i, BusinessArray[i].lat, BusinessArray[i].lng, BusinessArray[i].city, BusinessArray[i].state, BusinessArray[i].country, BusinessArray[i].type, BusinessArray[i].description, BusinessArray[i].description2, BusinessArray[i].description3, BusinessArray[i].description4, BusinessArray[i].description5, BusinessArray[i].year, BusinessArray[i].phone, BusinessArray[i].fax, BusinessArray[i].email, BusinessArray[i].url, BusinessArray[i].ip, BusinessArray[i].subnet, BusinessArray[i].iprange, BusinessArray[i].target]
    }

    // code to fill type dropdown
    var option = '';
    for (var i = 0; i < typeArray.length; i++) {
        option += '<option value="' + (i + 1) + '">' + typeArray[i].trim() + '</option>';
    }
    $('#businessType').append(option);

    // code to fill city array for business

    for (var i = 0; i < BusinessArray.length; i++) {
        var result = searchCity(CityArr, BusinessArray[i].city)
        if (result == 0) {
            var len = CityArr.length;
            CityArr[len] = [BusinessArray[i].lat, BusinessArray[i].lng, BusinessArray[i].city, BusinessArray[i].state, BusinessArray[i].country]
        }
    }
    // code to fill city dropdown 
    var option1;
    for (var i = 0; i < CityArr.length; i++) {
        option1 += '<option value="' + CityArr[i][0] + "," + CityArr[i][1] + '">' + CityArr[i][2] + '</option>';
    }
    $('#BusinessCity').append(option1);

}

function BusinessCitychange() {
    var value = $("#BusinessCity").val(); // returns LatLng object
    var coords = value.split(',');
    var latLng = new google.maps.LatLng(parseFloat(coords[0]), parseFloat(coords[1]));
    map.setCenter(latLng);
    map.setZoom(10);
}

function ShowBusinessAddresses2(year, file4Array, counter, Total, slot) {
    if (loop3S == true) {
        return;
    }
    $("#messageBoxBusiness").val(counter + " of " + Total)
    var typeArray = [];
    var BusinessArray2 = [];
    // for (var i = 0; i < file4Array.length; i++) {
    var cells = file4Array.split(",");
    if (cells.length > 1) {
        //if (i != 0) {
        var obj = {};
        obj['lat'] = parseFloat(cells[0].replace(/"/g, ''));
        obj['lng'] = parseFloat(cells[1].replace(/"/g, ''));
        obj['city'] = cells[2].replace(/"/g, '').trim();
        obj['state'] = cells[3].replace(/"/g, '').trim();
        obj['country'] = cells[4].replace(/"/g, '').trim();
        obj['description'] = cells[5].replace(/"/g, '').trim();
        obj['type'] = cells[6].trim();
        obj['color'] = cells[7];
        obj['size'] = cells[8];
        obj['shape'] = cells[9];
        obj['description2'] = cells[10];
        obj['description3'] = cells[11];
        obj['description4'] = cells[12];
        obj['description5'] = cells[13];
        obj['year'] = cells[14];
        obj['phone'] = cells[15];
        obj['fax'] = cells[16];
        obj['email'] = cells[17];
        obj['url'] = cells[18];
        obj['ip'] = cells[19];
        obj['subnet'] = cells[20];
        obj['iprange'] = cells[21];
        obj['target'] = cells[22];
        BusinessArray2.push(obj);

        if ($.inArray(cells[6].replace(/"/g, ''), typeArray) == -1) {
            typeArray.push(cells[6].replace(/"/g, ''));
        }
        // }
    }
    // }

    var result = chunkArray(BusinessArray2, 100);
    var selectedyear = year;
    var icon = [];
    var type = $("#businessType option:selected").text();
    for (i = 0; i < result.length; i++) {
        var TempArraypoint = result[i];
        // setInterval(function () { 
        for (j = 0; j < TempArraypoint.length; j++) {
            if (selectedyear == 0) {
                if (TempArraypoint[j].shape.trim() == "pointer") {
                    var colorCode = getColorCode(TempArraypoint[j].color)
                    if (TempArraypoint[j].size == 't') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(10, 10), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 's') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(20, 20), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'm') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(30, 30), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'l') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(50, 50), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    // icon[j] =
                    //     {
                    //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                    //     }
                }
                else {
                    icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                }
                if (TempArraypoint[j].type == type) {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                else if (type == "Select Type") {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                        //label: TempArraypoint[j].city
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                marker.setMap(map);
                if (slot == 1) {
                    $("#BusinessSlider").val(TempArraypoint[j].year.trim());
                } else if (slot == 2) {
                    $("#BusinessSliderReverse").val(TempArraypoint[j].year.trim());
                }

                //var len = ImageMarkerArray.length;
                //var colorCode1 = getColorCode(TempArraypoint[j].color)
                //ImageMarkerArray[len] = [TempArraypoint[j].lat, TempArraypoint[j].lng, colorCode1.trim(), TempArraypoint[j].shape.trim(), TempArraypoint[j].color.trim()]
                //ExportBusiness(marker, TempArraypoint[j].lat, TempArraypoint[j].lng);
            }
            else if (TempArraypoint[j].year.trim() == selectedyear) {
                if (TempArraypoint[j].shape.trim() == "pointer") {
                    var colorCode = getColorCode(TempArraypoint[j].color)
                    if (TempArraypoint[j].size == 't') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(10, 10), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 's') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(20, 20), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'm') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(30, 30), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'l') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(50, 50), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    // icon[j] =
                    //     {
                    //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                    //     }
                }
                else {
                    icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                }
                if (TempArraypoint[j].type == type) {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                else if (type == "Select Type") {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                        //label: TempArraypoint[j].city
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                marker.setMap(map);
                var len = ImageMarkerArray.length;
                //var colorCode1 = getColorCode(TempArraypoint[j].color)
                //ImageMarkerArray[len] = [TempArraypoint[j].lat, TempArraypoint[j].lng, colorCode1.trim(), TempArraypoint[j].shape.trim(), TempArraypoint[j].color.trim()]
                //ExportBusiness(marker, TempArraypoint[j].lat, TempArraypoint[j].lng);
            }

        }
        //  }, 2000);
    }
}


function ShowBusinessAddresses(year) {
    var result = chunkArray(BusinessArray, 100);
    var selectedyear = year;
    var icon = [];
    var type = $("#businessType option:selected").text();
    for (i = 0; i < result.length; i++) {
        var TempArraypoint = result[i];
        // setInterval(function () { 
        for (j = 0; j < TempArraypoint.length; j++) {
            if (selectedyear == 0) {
                if (TempArraypoint[j].shape.trim() == "pointer") {
                    var colorCode = getColorCode(TempArraypoint[j].color)
                    if (TempArraypoint[j].size == 't') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(10, 10), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 's') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(20, 20), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'm') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(30, 30), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'l') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(50, 50), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    // icon[j] =
                    //     {

                    //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                    //     }
                }
                else {
                    icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                }
                if (TempArraypoint[j].type == type) {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                else if (type == "Select Type") {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                        //label: TempArraypoint[j].city
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                marker.setMap(map);
                //var len = ImageMarkerArray.length;
                //var colorCode1 = getColorCode(TempArraypoint[j].color)
                //ImageMarkerArray[len] = [TempArraypoint[j].lat, TempArraypoint[j].lng, colorCode1.trim(), TempArraypoint[j].shape.trim(), TempArraypoint[j].color.trim()]
                //ExportBusiness(marker, TempArraypoint[j].lat, TempArraypoint[j].lng);
            }
            else if (TempArraypoint[j].year.trim() == selectedyear) {
                if (TempArraypoint[j].shape.trim() == "pointer") {
                    var colorCode = getColorCode(TempArraypoint[j].color)
                    if (TempArraypoint[j].size == 't') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(10, 10), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 's') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(20, 20), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'm') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(30, 30), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    else if (TempArraypoint[j].size == 'l') {
                        icon[j] =
                        {
                            url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode, // url
                            scaledSize: new google.maps.Size(50, 50), // scaled size
                            //origin: new google.maps.Point(0,0), // origin
                            //anchor: new google.maps.Point(0, 0) // anchor
                        }
                    }
                    // icon[j] =
                    //     {
                    //         url: "https://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + colorCode
                    //     }
                }
                else {
                    icon[j] = GetIcon(TempArraypoint[j].shape, TempArraypoint[j].size, TempArraypoint[j].color)
                }
                if (TempArraypoint[j].type == type) {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                else if (type == "Select Type") {
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(TempArraypoint[j].lat, TempArraypoint[j].lng),
                        map: map,
                        icon: icon[j],
                        title: TempArraypoint[j].lat + "," + TempArraypoint[j].lng,
                        //label: TempArraypoint[j].city
                    })
                    if (TempArraypoint[j].description.trim() != "") {
                        addInfoWindow(marker, TempArraypoint[j].description.trim());
                    }
                }
                marker.setMap(map);
                var len = ImageMarkerArray.length;
                //var colorCode1 = getColorCode(TempArraypoint[j].color)
                //ImageMarkerArray[len] = [TempArraypoint[j].lat, TempArraypoint[j].lng, colorCode1.trim(), TempArraypoint[j].shape.trim(), TempArraypoint[j].color.trim()]
                //ExportBusiness(marker, TempArraypoint[j].lat, TempArraypoint[j].lng);
            }

        }
        //  }, 2000);
    }
}

var b = 0;
var timerBusiness;
function BusinessAutoScan() {
    timerBusiness = setTimeout(function () {
        var latLng = new google.maps.LatLng(parseFloat(CityArr[b][0]), parseFloat(CityArr[b][1]));
        map.setCenter(latLng);
        // map.setZoom(10);
        var zoomLevelB = $("#zoomBusiness").val();
        map.setZoom(parseInt(zoomLevelB));
        $("#BusinessCityStateCountry").val("City :" + CityArr[b][2] + ", " + "State :" + CityArr[b][3] + ", " + "Country :" + CityArr[b][4]);
        document.getElementById('BusinessCityStateCountry').innerHTML = CityArr[b][2] + ", " + CityArr[b][3] + ", " + CityArr[b][4];
        b++;
        if (b < CityArr.length) {
            BusinessAutoScan();
        }
    }, 5000)
}

function AbortBusinessScan() {
    clearTimeout(timerBusiness);
}


function forceDownload(url, fileName) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.responseType = "blob";
    xhr.onload = function () {
        var urlCreator = window.URL || window.webkitURL;
        var imageUrl = urlCreator.createObjectURL(this.response);
        var tag = document.createElement('a');
        tag.href = imageUrl;
        tag.download = fileName;
        document.body.appendChild(tag);
        tag.click();
        document.body.removeChild(tag);
    }
    xhr.send();
}


function searchCity(arr, city) {
    var result = 0;
    for (var i = 0, len = arr.length; i < len; i++) {
        if (arr[i][2] == city) {
            result = 1;
            break;
        }
    }
    return result;
}

function openAllInfoWindows() {
    for (var i = 0; i < infoWindows.length; i++) {
        infoWindows[i]['infoWinObj'].open(map, infoWindows[i]['markerObj']);
    }
}

function closeAllInfoWindows() {
    for (var i = 0; i < infoWindows.length; i++) {
        if (infoWindows[i]['infoWinObj'])
            infoWindows[i]['infoWinObj'].close();
    }
}

function SetZoom() {
    var zoomLevel = $("#zoom").val();
    map.setZoom(parseInt(zoomLevel));
}

function largestInColumn(arr) {
    debugger
    var maxm = arr[0][12];
    for (var j = 1; j < arr.length; j++)
        if (arr[j][12] > maxm)
            maxm = arr[j][12];
    return maxm;
}

function SmallestInColumn(arr) {
    var minm = arr[0][12];
    for (var j = 1; j < arr.length; j++)
        if (arr[j][12] < minm)
            minm = arr[j][12];
    return minm;
}

function searchLocation(arr, location,state) {
    var result = 0;
    for (var i = 0, len = arr.length; i < len; i++) {
        if (arr[i][0] == location && arr[i][1] == state) {
            result = 1;
            break;
        }
    }
    return result;
}

function searchSpecialLocation(arr, state) {
    var result = 0;
    for (var i = 0, len = arr.length; i < len; i++) {
        if (arr[i][0] == state) {
            result = 1;
            break;
        }
    }
    return result;
}
